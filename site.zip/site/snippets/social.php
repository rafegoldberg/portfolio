<ul class="list list_padded card_big <?=isset($wrap)?$wrap:''?>">
	<a href="http://dribbble.com/rgd2">
		<li class="list--item <?=isset($items)?$items:''?>">
			<span class="iconic d-ib va-m" data-glyph="shape-circle"></span>
			<span class="d-ib va-m">Dribbble</span>
		</li>
	</a>
	<a href="http://github.com/rafegoldberg">
		<li class="list--item <?=isset($items)?$items:''?>">
			<span class="iconic d-ib va-m" data-glyph="social-github"></span>
			<span class="d-ib va-m">Github</span>
		</li>
	</a>
	<a href="http://www.linkedin.com/pub/rafe-goldberg/35/993/262">
		<li class="list--item <?=isset($items)?$items:''?>">
			<span class="iconic d-ib va-m" data-glyph="social-linkedin"></span>
			<span class="d-ib va-m">LinkedIn</span>
		</li>
	</a>
</ul>