<h1>
	<a href="<?=url()?>"><?= $site->title()->html() ?></a>
</h1>