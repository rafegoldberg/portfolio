<footer id="footer" role="contentinfo" class="<?=isset($class)?$class:''?>">
	<?= $site->copyright()->kirbytext() ?>
</footer>