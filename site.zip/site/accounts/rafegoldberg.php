<?php if(!defined('KIRBY')) exit ?>

username: rafegoldberg
email: rafegoldberg@gmail.com
password: >
  $2a$10$2uQFoPKLAh5MLEtSK7yqBe8NcOAPKvxmkixrSdtb5vCOY8XgttQ.C
language: en
role: admin
token: 878ad97496c39e02a66134a15600076a971ad580
history:
  - projects/christian-et-christine
  - projects/dot-bk
  - projects/wilshire-skyline
  - projects/larrc
  - null
