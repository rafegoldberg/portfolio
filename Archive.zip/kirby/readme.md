# Kirby Core

This is the Kirby Core submodule.

Please refer to the [Kirby Starterkit](http://github.com/getkirby/starterkit)
for a complete installation of Kirby

![Build Status](https://travis-ci.org/getkirby/kirby.svg)

## Author
Bastian Allgeier
<bastian@getkirby.com>

## Website
<http://getkirby.com>

## License
<http://getkirby.com>