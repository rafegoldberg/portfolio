<?php if(!defined('KIRBY')) exit ?>

title: Projects
pages:
  template: project
files: false
fields:
  title:
    label: Title
    type:  text
  text:
    label: Text
    type:  textarea