<?php if(!defined('KIRBY')) exit ?>

username: rafegoldberg
email: rafegoldberg@gmail.com
password: >
  $2a$10$2uQFoPKLAh5MLEtSK7yqBe8NcOAPKvxmkixrSdtb5vCOY8XgttQ.C
language: en
role: admin
token: c5e51d1e86b7575c683006feade12eb54b14f6f7
history:
  - projects/ramsay-for-la
  - projects/larrc
  - home
  - projects/dot-bk
  - projects
