<div class="box--content box_list">
	<<?=$tag?> class="box--content--list <?=$list_class?>">
		<?=$text?>
	</<?=$tag?>>
</div>
