<? if (isset($content)) : ?>
	<figure class="box--content--int <?=isset($class)?$class:''?>">
		<?=$content?>
	</figure>
<? endif ?>