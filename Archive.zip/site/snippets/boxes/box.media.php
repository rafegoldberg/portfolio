<div class="box--content box_media">
	<img src="<?=$media_src?>" class="box--content--media" />
</div>