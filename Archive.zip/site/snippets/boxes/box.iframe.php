<div class="box--content box_media box_iframe">
	<?= $iframe_tag ?>
</div>
