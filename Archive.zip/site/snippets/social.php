<ul class="list_sep-slash list_padded ta-center card_big">
	<li class="list--item social-1">
		<a href="#network-1" class="iconic" data-glyph="shape-circle"> Dribbble</a>
	</li>
	<li class="list--item social-2">
		<a href="#network-2" class="iconic" data-glyph="social-github"> GitHub</a>
	</li>
	<li class="list--item social-3">
		<a href="#network-3" class="iconic" data-glyph="social-linkedin"> LinkedIn</a>
	</li>
</ul>