<header id="header" class="gutter-top" role="banner">
	<? snippet('site-brand') ?>
</header>