<div id="scripts">
	<!--PHP = js(array(
		'assets/js/modernizr.js'             ,
		'assets/js/jquery.js'                ,
		'assets/js/pre/jquery.event.move.js' ,
		'assets/js/pre/jquery.event.swipe.js',
		'assets/js/pre/lib.unslider.js'      ,
		'assets/js/main.js'                  ,
		'assets/js/post/config.unslider.js'  ,
	)) -->
	<?= js('assets/js/build/main.js') ?>
</div>
</body>
</html>