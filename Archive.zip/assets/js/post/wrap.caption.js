$(document).ready(function() {
	$('.figure--caption')
		.addClass('block-center-solo')
		.wrapInner('<div class="legible-block"></div>');
});