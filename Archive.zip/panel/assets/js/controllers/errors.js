/**
 *
 */
var ErrorsController = {
  index : function(path) {
    app.main.view('errors/index');
  }
};