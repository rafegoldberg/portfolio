username:
  label: login.username.label
  type: text
  icon: user
  required: true
  autofocus: true
password:
  label: login.password.label
  type: password
  required: true